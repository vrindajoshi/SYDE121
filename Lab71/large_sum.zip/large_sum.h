#ifndef LARGE_SUM_H
#define LARGE_SUM_H
#include <string>

void enter_nums(string &n1, string &n2, bool &run);
string add_large_numbers(string n1, string n2);
void display_num(string sum);
void end();

#endif //LARGE_SUM_H