//*********************************************
// Student Name: Vrinda Joshi
// Student Number: 21181781
//
// SYDE121 Lab: 1 Task: 1
//
// Filename: lab0101.cpp
// Date submitted: 09/12/2025
//
// I hereby declare that this code, submitted
// for credit for the course SYDE121, is a product
// of my own efforts. This coded solution has
// not been plagiarized from other sources and
// as not been knowingly plagiarized by others.

#include <iostream>
using namespace std;

int main() {
    int i = 0;

    for (i = 3; i <= 10; i++) {
        cout << "i = " << i << " squared = " << i * i << endl;
    }

    cout << "\nA program by: Vrinda Joshi\n";

    return 0;

}